#ifndef _version_h
#define _version_h

#define VERSION "1.0.0"
#define APPLICATION "SDesk v" VERSION

#endif
